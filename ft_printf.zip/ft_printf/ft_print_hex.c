/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_hex.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mouaguil <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/11/05 18:30:10 by mouaguil          #+#    #+#             */
/*   Updated: 2025/11/06 14:59:54 by mouaguil         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

int	ft_print_hex(unsigned int hex, int up_or_low)
{
	int		count;
	char	*base_up;
	char	*base_low;
	char	*base;

	base_up = "0123456789ABCDEF";
	base_low = "0123456789abcdef";
	if (!up_or_low)
		base = base_low;
	else
		base = base_up;
	count = 0;
	if (hex >= 16)
		count += ft_print_hex(hex / 16, up_or_low);
	count += ft_print_char(base[hex % 16]);
	return (count);
}
