/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_unsigned.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mouaguil <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/11/05 15:15:09 by mouaguil          #+#    #+#             */
/*   Updated: 2025/11/06 17:34:21 by mouaguil         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

int	ft_print_unsigned(unsigned int n)
{
	char			c;
	int				count;

	count = 0;
	if (n / 10)
		count += ft_print_unsigned(n / 10);
	c = n % 10 + '0';
	count += write (1, &c, 1);
	return (count);
}
