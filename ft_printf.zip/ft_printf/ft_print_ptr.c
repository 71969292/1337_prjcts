/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_ptr.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mouaguil <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/11/05 15:23:01 by mouaguil          #+#    #+#             */
/*   Updated: 2025/11/06 15:24:45 by mouaguil         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

int	printing(unsigned long p)
{
	int			count;
	char		*base;

	base = "0123456789abcdef";
	count = 0;
	if (p >= 16)
		count += printing(p / 16);
	count += ft_print_char(base[p % 16]);
	return (count);
}

int	ft_print_ptr(void *ptr)
{
	int				count;
	unsigned long	p;

	p = (unsigned long)ptr;
	if (!p)
	{
		write(1, "(nil)", 5);
		return (5);
	}
	count = ft_print_str("0x") + printing(p);
	return (count);
}
