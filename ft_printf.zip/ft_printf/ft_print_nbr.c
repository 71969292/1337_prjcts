/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_nbr.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mouaguil <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/10/21 11:58:29 by mouaguil          #+#    #+#             */
/*   Updated: 2025/11/06 17:31:26 by mouaguil         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

int	ft_print_nbr(int n)
{
	char		c;
	long		num;
	int			count;

	num = n;
	count = 0;
	if (num < 0)
	{
		write(1, "-", 1);
		num = -num;
		count++;
	}
	if (num / 10)
		count += ft_print_nbr(num / 10);
	c = num % 10 + '0';
	count += write (1, &c, 1);
	return (count);
}
