/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mouaguil <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/11/05 15:55:01 by mouaguil          #+#    #+#             */
/*   Updated: 2025/11/06 14:31:52 by mouaguil         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_PRINTF_H
# define FT_PRINTF_H

# include <stdarg.h>
# include <unistd.h>

int	ft_print_char(char c);
int	ft_print_hex(unsigned int hex, int up_or_low);
int	ft_printf(const char *b, ...);
int	ft_print_nbr(int n);
int	ft_print_ptr(void *ptr);
int	ft_print_str(char *s);
int	ft_print_unsigned(unsigned int n);

#endif
