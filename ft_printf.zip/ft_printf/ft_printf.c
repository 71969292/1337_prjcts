/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mouaguil <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/11/05 16:05:47 by mouaguil          #+#    #+#             */
/*   Updated: 2025/11/06 16:47:54 by mouaguil         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

char	*ft_strchr(const char *s, int c)
{
	int	i;

	i = 0;
	if ((char)c == '\0')
	{
		while (*s)
			s++;
		return ((char *)s);
	}
	while (s[i])
	{
		if (s[i] == (char)c)
			return ((char *)&s[i]);
		i++;
	}
	return (NULL);
}

int	parsing(va_list args, char specifier)
{
	int	count;

	count = 0;
	if (specifier == 'c')
		count += ft_print_char(va_arg(args, int));
	else if (specifier == 's')
		count += ft_print_str(va_arg(args, char *));
	else if (specifier == 'p')
		count += ft_print_ptr(va_arg(args, void *));
	else if (specifier == 'd' || specifier == 'i')
		count += ft_print_nbr(va_arg(args, int));
	else if (specifier == 'u')
		count += ft_print_unsigned(va_arg(args, unsigned int));
	else if (specifier == 'x')
		count += ft_print_hex(va_arg(args, unsigned int), 0);
	else if (specifier == 'X')
		count += ft_print_hex(va_arg(args, unsigned int), 1);
	else if (specifier == '%')
		count += ft_print_char('%');
	return (count);
}

int	ft_printf(const char *b, ...)
{
	int		count;
	int		i;
	va_list	args;

	va_start(args, b);
	count = 0;
	i = 0;
	while (b[i])
	{
		if (b[i] == '%' && b[i + 1] && ft_strchr("cspdiuxX%", b[i + 1]))
		{
			count += parsing(args, b[i + 1]);
			i = i + 2;
		}
		else
		{
			count += ft_print_char(b[i]);
			i++;
		}
	}
	va_end(args);
	return (count);
}
